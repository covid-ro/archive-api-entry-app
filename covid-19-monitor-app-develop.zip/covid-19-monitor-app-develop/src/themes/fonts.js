const fonts = {};
export default fonts;
