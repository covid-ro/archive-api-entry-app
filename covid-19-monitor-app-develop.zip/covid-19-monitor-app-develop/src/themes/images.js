const images = {
  logo: require('../../assets/images/logo.png'),
  ic_check: require('../../assets/images/ic_check.png'),
  ic_tick: require('../../assets/images/ic_tick.png'),
};

export default images;
