const roots = {
  countriesCrossed: 'countriesCrossed',
  languageSelect: 'LanguageSelect',
  informationScreen: 'InformationScreen',
  registerStack: 'RegisterStack',
  finishNavigator: 'FinishNavigator',
  finishScreen: 'FinishScreen',
  endScreen: 'EndScreen',
  sendNumber: 'SendNumber',
  sendCode: 'SendCode',
};
export default roots;
