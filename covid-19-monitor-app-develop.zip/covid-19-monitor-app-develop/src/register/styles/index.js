export {default as registerScreenStyles} from './registerScreenStyles';
export {default as countriesCrossedScreenStyles} from './countriesCrossedScreenStyles';
export {default as informationScreenStyles} from './informationScreenStyles';
