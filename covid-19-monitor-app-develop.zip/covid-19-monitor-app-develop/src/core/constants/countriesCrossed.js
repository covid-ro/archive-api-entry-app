const countriesCrossed = [
  {id: 0, data: 'Italia'},
  {id: 1, data: 'Germania'},
  {id: 2, data: 'Franta'},
  {id: 3, data: 'Spania'},
  {id: 4, data: 'Republica Moldova'},
  {id: 5, data: 'Olanda'},
  {id: 6, data: 'China'},
];

export default countriesCrossed;
