export const IOS = 'ios';
export const ANDROID = 'android';
