export {default as strings} from './strings';
