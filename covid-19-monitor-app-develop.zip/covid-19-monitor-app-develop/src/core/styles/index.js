export {default as labelStyles} from './labelStyles';
